import java.io.*;
import java.util.Scanner;

public class Project1 {
	public static void main(String[] args) {
		Scanner sc = null;
		FileOutputStream fos = null;
		String s;
		int numRows = 0;
		int numCols = 0;
		int minVal = 0;
		int maxVal = 0;
		int hist[] = null;
		
		//step 0: open input and output files
		try {
			sc = new Scanner(new File(args[0]));
		} catch(ArrayIndexOutOfBoundsException e){
			e.printStackTrace();
			System.out.println("No argument");
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Cant find the file" + args[0]);
		}
		
		//step 1: initialize 
		try {
			numRows = sc.nextInt();
			numCols = sc.nextInt();
			minVal = sc.nextInt();
			maxVal = sc.nextInt();
			hist = new int[maxVal+1];
			
			//step 2&3: read from file, until file empty
			while(sc.hasNext()) {
				hist[sc.nextInt()]++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
		
		//set output to output file
		try {
			fos = new FileOutputStream(args[1]);
			System.setOut(new PrintStream(fos));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		//step 4: output histogram array to output file 
		for(int i = 0; i < maxVal + 1; i++){
			System.out.println(i + " " + hist[i]);
		}
		
		//step 5: close input file and output file
		try {
			fos.close();
			System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		} catch (IOException e) {
			e.printStackTrace();
		}
		System.out.println("Done");
	}
}
