import java.io.*;

public class Project2 {
	public static void main(String[] args) {
		//set output to output file
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(args[1]);
			System.setOut(new PrintStream(fos));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		//step 0,1
		AVG3X3 a = new AVG3X3(args[0]);
		
		//step 2
		a.mirrorFramed();
		
		//step 3,4
		a.Averaging();
		
		//step 5,6
		a.printTempA();
		
		//step 7: close input file and output file
		try {
			fos.close();
			System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Done");
	}
}
