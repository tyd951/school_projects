import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

public class Project8_2 {
	public static void main(String[] args) {
		//step 0
		int k = 0;
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try{
			System.out.println("argument 1:" + args[0]);
			System.out.println("argument 2:" + args[1]);
			System.out.println("argument 3:" + args[2]);
			System.out.println("argument 4:" + args[3]);
		}catch(ArrayIndexOutOfBoundsException e){
			System.out.println("no arguments");
			System.exit(0);
		}
		
		System.out.println("Give me a K:");
		try{
			k = Integer.parseInt(br.readLine());
		} catch (IOException e) {
			e.printStackTrace();
		} catch(NumberFormatException e){
			System.out.println("input is not a number!");
			System.exit(0);
		}
		
		image i = new image(args[0]);
		
		arcChord ac = new arcChord(i.numPts,k);
		ac.loadData(args[0]);
		//ac.printPtAry();
		//step 1		
		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(args[3]);
			System.setOut(new PrintStream(fos));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		
		int P1 = 0;
		int P2 = 2*k - 1;
		int index = 0;
		int currPtIndex = 0;
		int maxIndex;
		double dist = 0.0;
		//step 2 - 9
		do {
			index = 0;
			currPtIndex = (P1 + 1) % ac.numPts;
			while(index < 2*k){
				dist = ac.computeDistance(P1, P2, currPtIndex);
				ac.chordAry[index] = dist;
				index++;
				currPtIndex = (currPtIndex + 1) % ac.numPts;
			}
			//ac.printChordAry();
			maxIndex = ac.findMax();
			ac.PtAry[(P1+maxIndex+1) % ac.numPts].maxVotes++;
			if(ac.PtAry[(P1+maxIndex+1) % ac.numPts].maxDist < dist){
				ac.PtAry[(P1+maxIndex+1) % ac.numPts].maxDist = dist;
			}
			//ac.printPtAry(P1, P2);
			P1 = (P1+1) % ac.numPts;
			P2 = (P2+1) % ac.numPts;
		}while(P2 != 2*k-1);
		ac.printVotes();
		//step 10
		ac.print5();
		
		//step 11 12
		ac.computeLocalMax();
		ac.setCorner();
		
		//step 13
		try {
			fos = new FileOutputStream(args[1]);
			System.setOut(new PrintStream(fos));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		ac.printCorners();
		
		//step 14 15
		i.plotPt2Img(ac);
		
		//step 16
		try {
			fos = new FileOutputStream(args[2]);
			System.setOut(new PrintStream(fos));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		i.prettyPrint();
		
		//step17
		try {
			fos.close();
			br.close();
		} catch (IOException e) {
			e.printStackTrace();
		}
		
	}
}
