import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class arcChord {
	int numRows;
	int numCols;
	int minVal;
	int maxVal;
	int label;
	
	int chordLength;
	int numPts;

	boundaryPt[] PtAry;
	double[] chordAry;
	
	public arcChord(int num, int k){
		chordLength = 2*k;
		numPts = num;
		PtAry = new boundaryPt[numPts];
		chordAry = new double[chordLength];
	}
	
	public void loadData(String input){
		Scanner sc = null;
		try {
			sc = new Scanner(new File(input));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Cant find the file" + input);
		}
		try {
			numRows = sc.nextInt();
			numCols = sc.nextInt();
			minVal = sc.nextInt();
			maxVal = sc.nextInt();
			label = sc.nextInt();
			int counter = 0;
			int r = 0;
			int c = 0;
			while(sc.hasNextInt()){
				r = sc.nextInt();
				c = sc.nextInt();
				PtAry[counter] = new boundaryPt(r,c);
				counter++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
	
	public double computeDistance(int p1, int p2, int currPtIndex){
		double dist = 0.0;
		int x = PtAry[currPtIndex].x;
		int y = PtAry[currPtIndex].y;
		int x1 = PtAry[p1].x;
		int x2 = PtAry[p2].x;
		int y1 = PtAry[p1].y;
		int y2 = PtAry[p2].y;
		double A = y2 - y1 + 0.00001;
		double B = x1 - x2 + 0.00001;
		double C = x2 * y1 - x1 * y2 + 0.00001;
		
		dist = Math.abs(A*x + B*y + C) / Math.sqrt(A*A + B*B);
		
		return dist;
	}
	
	public int findMax(){
		int maxIndex = 0;
		for(int i = 1; i < chordAry.length; i++){
			if(chordAry[i] > chordAry[maxIndex]){
				maxIndex = i;
			}
		}
		return maxIndex;
	}
	
	public void computeLocalMax(){
		int first = 0;
		int second = 0;
		int third = 0;
		int forth = 0;
		for(int i = 0; i < numPts; i++){
			first = (i + numPts -2) % numPts;
			second = (i + numPts -1) % numPts;
			third = (i + 1) % numPts;
			forth = (i + 2) % numPts;
			
			if(PtAry[i].maxVotes > PtAry[first].maxVotes
					&&PtAry[i].maxVotes > PtAry[second].maxVotes
					&&PtAry[i].maxVotes > PtAry[third].maxVotes
					&&PtAry[i].maxVotes > PtAry[forth].maxVotes){
				PtAry[i].localMax++;
			}
		}
	}
	
	public void setCorner(){
		int first = 0;
		int forth = 0;
		for(int i = 0; i < numPts; i++){
			first = (i + numPts -2) % numPts;
			forth = (i + 2) % numPts;
			
			if(PtAry[first].localMax == 0
					&&PtAry[forth].localMax == 0
					&&PtAry[i].localMax == 1){
				PtAry[i].corner = 9;
			}
			else
				PtAry[i].corner = 1;
		}
	}
	
	public void printPtAry(){
		for(int i = 0; i < numPts; i++){
			PtAry[i].printPt();
		}
	}
	
	public void printPtAry(int p1, int p2){
		System.out.println("From " + p1 + " to " + p2);
		for(int i = p1; i < numPts + p2; i++){
			PtAry[i%numPts].printPt();
		}
	}
	
	public void print5(){
		System.out.println("Five pts per text line:");
		for(int i = 0; i < numPts; i++){
			PtAry[i].printPtInOneLine();
			if((i+1)%5 == 0){
				System.out.println();
			}
		}
	}
	
	public void printChordAry(){
		System.out.println("ChordAry:");
		for(int i = 1; i < chordAry.length; i++){
			System.out.println(chordAry[i]);
		}
	}
	
	public void printCorners(){
		System.out.println(numRows + " " + numCols + " " + minVal + " " + maxVal);
		System.out.println(label);
		for(int i = 0; i < numPts; i++){
			PtAry[i].printCorner();
		}
	}
	
	public void printVotes(){
		for(int i = 0; i < numPts; i++){
			PtAry[i].printVotes();
		}
	}
}
