import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class image {
	int numRows;
	int numCols;
	int minVal;
	int maxVal;
	int label;
	int numPts;
	int[][] img;
	
	public image(String input){
		numPts = 0;
		Scanner sc = null;
		try {
			sc = new Scanner(new File(input));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Cant find the file" + input);
		}
		
		try {
			numRows = sc.nextInt();
			numCols = sc.nextInt();
			minVal = sc.nextInt();
			maxVal = sc.nextInt();
			label = sc.nextInt();
			
			img = new int[numRows][numCols];

			while(sc.hasNextInt()){
				sc.nextInt();
				sc.nextInt();
				numPts++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
	
	public void plotPt2Img(arcChord ac){
		int r = 0;
		int c = 0;
		int corner = 0;
		for(int i = 0; i < ac.PtAry.length; i++){
			r = ac.PtAry[i].x;
			c = ac.PtAry[i].y;
			corner = ac.PtAry[i].corner;
			img[r][c] = corner;
		}
	}
	
	public void prettyPrint(){
		for(int i = 0; i < numRows; i++){
			for(int j = 0; j < numCols; j++){
				if(img[i][j] > 0){
					System.out.print(img[i][j] + " ");
				}
				else{
					System.out.print("  ");
				}
			}
			System.out.println();
		}
	}
}
