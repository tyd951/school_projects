import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class AVG3X3 {
	int numRows = 0;
	int numCols = 0;
	int minVal = 0;
	int maxVal = 0;
	int newMin = 0;
	int newMax = 0;
	int mirrorFramedAry[][] = null;
	int tempAry[][] = null;
	int neighborAry[] = null;
	
	//constructor
	public AVG3X3(String input){
		Scanner sc = null;
		neighborAry = new int[9];
		
		try {
			sc = new Scanner(new File(input));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Cant find the file" + input);
		}
		
		try {
			numRows = sc.nextInt();
			numCols = sc.nextInt();
			minVal = sc.nextInt();
			maxVal = sc.nextInt();
			mirrorFramedAry = new int[numRows + 2][numCols + 2];
			tempAry = new int[numRows + 2][numCols + 2];
			
			int counter = 0;
			int r = 0;
			int c = 0;
			while(sc.hasNextInt()){
				r = counter/numCols + 1;
				c = counter%numCols + 1;
				mirrorFramedAry[r][c] = sc.nextInt();
				counter++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
	
	public void mirrorFramed(){
		for(int i = 1; i < numCols + 1; i++){
			mirrorFramedAry[0][i] = mirrorFramedAry[1][i];
			mirrorFramedAry[numRows + 1][i] = mirrorFramedAry[numRows][i];
		}
		for(int j = 0; j < numRows + 2; j++){
			mirrorFramedAry[j][0] = mirrorFramedAry[j][1];
			mirrorFramedAry[j][numCols + 1] = mirrorFramedAry[j][numCols];
		}
	}
	
	private void loadNeighbors(int r, int c){
		int index = 0;
		for(int i = -1;i < 2; i++){
			for(int j = -1; j < 2; j++){
				neighborAry[index] = mirrorFramedAry[r+i][c+j];
				index++;
			}
		}
		int avg = AvgNeighbor();
		if(avg < newMin){
			newMin = avg;
		}
		else if(avg > newMax){
			newMax = avg;
		}
		tempAry[r][c] = avg;
	}
	
	private int AvgNeighbor(){
		int sum = 0;
		for(int i = 0; i < 9; i++){
			sum += neighborAry[i];
		}
		return sum/9;
	}
	
	public void Averaging(){
		for(int i = 1; i < numRows + 1; i++){
			for(int j = 1; j < numCols + 1; j++){
				loadNeighbors(i,j);
			}
		}
	}
	
	public void printTempA(){
		System.out.println(numRows + " " + numCols + " " + newMin + " " + newMax);
		for(int i = 1; i < numRows + 1; i++){
			for(int j = 1; j < numCols + 1; j++){
				System.out.print(tempAry[i][j] + " ");
			}
			System.out.println();
		}
	}
}
