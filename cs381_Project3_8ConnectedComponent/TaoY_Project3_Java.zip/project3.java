import java.io.FileDescriptor;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;

public class project3 {
	public static void main(String[] args) {
		FileOutputStream fos = null;

		//step 0,1
		EightCC ec = new EightCC(args[0]);

		try {
			fos = new FileOutputStream(args[1]);
			System.setOut(new PrintStream(fos));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		//step 2
		System.out.println("------- Pass 1 -------");
		ec.eightCC_Pass1();
		ec.prettyPrint();
		ec.printEQ();
		
		//step 3
		System.out.println("------- Pass 2 -------");
		ec.eightCC_Pass2();
		ec.prettyPrint();
		ec.printEQ();
		
		//step 4
		System.out.println("------- ManageEQ -------");
		ec.manageEQAry();
		ec.printEQ();
		
		//step 5
		System.out.println("------- Pass 3 -------");
		ec.eightCC_Pass3();
		ec.prettyPrint();
		
		try {
			fos = new FileOutputStream(args[2]);
			System.setOut(new PrintStream(fos));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		ec.createImg();
		
		try {
			fos = new FileOutputStream(args[3]);
			System.setOut(new PrintStream(fos));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
		ec.printCCProperty();
		
		//done
		try {
			fos.close();
			System.setOut(new PrintStream(new FileOutputStream(FileDescriptor.out)));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		System.out.println("Done");
	}
}
