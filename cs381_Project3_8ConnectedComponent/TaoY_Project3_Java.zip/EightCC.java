import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class EightCC {
	class Property{
		int numpx;
		int minCol;
		int maxCol;
		int minRow;
		int maxRow;
		Property(){
			numpx = 0;
			minCol = 99;
			maxCol = 0;
			minRow = 99;
			maxRow = 0;
		}
	}
	int numRows;
	int numCols;
	int minVal;
	int maxVal;
	int newMin;
	int newMax;
	int newLabel;
	int[][] zeroFramedAry;
	int[] neighborAry;
	int[] EQAry;
	Property[] properties;
	
	public EightCC(String input){
		Scanner sc = null;
		newMin = 1;
		newMax = 0;
		newLabel = 0;
		neighborAry = new int[5];
		
		try {
			sc = new Scanner(new File(input));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
			System.out.println("Cant find the file" + input);
		}
		
		try {
			numRows = sc.nextInt();
			numCols = sc.nextInt();
			minVal = sc.nextInt();
			maxVal = sc.nextInt();
			
			//zeroFramed
			zeroFramedAry = new int[numRows + 2][numCols + 2];
			EQAry = new int[numRows * numCols / 2];
			for(int i = 0; i < EQAry.length; i++){
				EQAry[i] = i;
			}
			
			//loadimage
			int counter = 0;
			int r = 0;
			int c = 0;
			while(sc.hasNextInt()){
				r = counter/numCols + 1;
				c = counter%numCols + 1;
				zeroFramedAry[r][c] = sc.nextInt();
				counter++;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			sc.close();
		}
	}
	
	private void loadNeighbors1(int i, int j){
		neighborAry[0] = this.zeroFramedAry[i - 1][j - 1];
		neighborAry[1] = this.zeroFramedAry[i - 1][j];
		neighborAry[2] = this.zeroFramedAry[i - 1][j + 1];
		neighborAry[3] = this.zeroFramedAry[i][j - 1];
	}
	
	public void eightCC_Pass1(){
		for(int i = 1; i < numRows + 1; i++){
			for(int j = 1; j < numCols + 1; j++){
				if(zeroFramedAry[i][j] > 0){
					loadNeighbors1(i,j);
					//case 1
					if(neighborAry[0]==0 && neighborAry[1]==0 && neighborAry[2]==0 && neighborAry[3]==0){
						newLabel ++;
						zeroFramedAry[i][j] = newLabel;
					}
					//case 2 & 3
					else {
						int min = minNeighbor1();
						int max = maxNeighbor1();
						
						//case 2
						if(min == max){
							zeroFramedAry[i][j] = min;
						}
						
						//case 3
						else{
							zeroFramedAry[i][j] = min;
							updateEQAry1(min);
						}
					}
				}
			}
		}
	}
	
	private int minNeighbor1(){
		//find non-zero min
		int min = 99;
		for(int i = 0; i < neighborAry.length - 1; i++){
			if(neighborAry[i] < min && neighborAry[i] > 0) min = neighborAry[i];
		}
		return min;
	}
	
	private int maxNeighbor1(){
		int max = neighborAry[0];
		for(int i = 1; i < neighborAry.length - 1; i++){
			if(neighborAry[i] > max) max = neighborAry[i];
		}
		return max;
	}
	
	private void updateEQAry1(int m){
		for(int i = 0; i < neighborAry.length - 1; i++){
			if(neighborAry[i] > m){
				EQAry[neighborAry[i]] = m;
			}
		}
	}
	
	private void loadNeighbors2(int i, int j){
		neighborAry[0] = this.zeroFramedAry[i][j]; //itself
		neighborAry[1] = this.zeroFramedAry[i][j + 1];
		neighborAry[2] = this.zeroFramedAry[i + 1][j - 1];
		neighborAry[3] = this.zeroFramedAry[i + 1][j];
		neighborAry[4] = this.zeroFramedAry[i + 1][j + 1];
	}
	
	public void eightCC_Pass2(){
		for(int i = numRows; i > 1; i--){
			for(int j = numCols; j > 1; j--){
				if(zeroFramedAry[i][j] > 0){
					loadNeighbors2(i,j);
					//case 1
					if(neighborAry[1]==0 && neighborAry[2]==0 && neighborAry[3]==0 && neighborAry[4]==0){
						continue;
					}
					//case 2 & 3
					else {
						int min = minNeighbor2();
						int max = maxNeighbor2();
						
						//case 2
						if(min == max){
							zeroFramedAry[i][j] = min;
						}
						
						//case 3
						else{
							zeroFramedAry[i][j] = min;
							updateEQAry2(min);
						}
					}
				}
			}
		}
	}
	
	private int minNeighbor2(){
		//find non-zero min
		int min = 99;
		for(int i = 0; i < neighborAry.length; i++){
			if(neighborAry[i] < min && neighborAry[i] > 0) min = neighborAry[i];
		}
		return min;
	}
	
	private int maxNeighbor2(){
		int max = neighborAry[0];
		for(int i = 1; i < neighborAry.length; i++){
			if(neighborAry[i] > max) max = neighborAry[i];
		}
		return max;
	}
	
	private void updateEQAry2(int m){
		for(int i = 0; i < neighborAry.length; i++){
			if(neighborAry[i] > m){
				EQAry[neighborAry[i]] = m;
			}
		}
	}
	
	public void manageEQAry(){
		int count = 0;
		for(int i = 1; i <= newLabel; i++){
			if(EQAry[i] == i){
				count ++;
				EQAry[i] = count;
			}
			else{
				EQAry[i] = EQAry[EQAry[i]];
			}
		}
		newMax = count;
		//initialize property table
		properties = new Property[count + 1];
		for(int i = 1; i < properties.length; i++){
			properties[i] = new Property();
		}
	}
	
	public void eightCC_Pass3(){
		for(int i = 1; i < numRows + 1; i++){
			for(int j = 1; j < numCols + 1; j++){
				if(zeroFramedAry[i][j] > 0){
					zeroFramedAry[i][j] = EQAry[zeroFramedAry[i][j]];
					properties[zeroFramedAry[i][j]].numpx++;
					if(i > properties[zeroFramedAry[i][j]].maxRow){
						properties[zeroFramedAry[i][j]].maxRow = i;
					}
					if(i < properties[zeroFramedAry[i][j]].minRow){
						properties[zeroFramedAry[i][j]].minRow = i;
					}
					if(j > properties[zeroFramedAry[i][j]].maxCol){
						properties[zeroFramedAry[i][j]].maxCol = j;
					}
					if(j < properties[zeroFramedAry[i][j]].minCol){
						properties[zeroFramedAry[i][j]].minCol = j;
					}
				}
			}
		}
	}
	
	public void prettyPrint(){
		for(int i = 1; i < numRows + 1; i++){
			for(int j = 1; j < numCols + 1; j++){
				if(zeroFramedAry[i][j] > 0 && zeroFramedAry[i][j] < 10){
					System.out.print(zeroFramedAry[i][j] + "  ");
				}
				else if(zeroFramedAry[i][j] >= 10){
					System.out.print(zeroFramedAry[i][j] + " ");
				}
				else{
					System.out.print("   ");
				}
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public void createImg(){
		System.out.println(numRows + " " + numCols + " " + newMin + " " + newMax);
		for(int i = 1; i < numRows + 1; i++){
			for(int j = 1; j < numCols + 1; j++){
				if(zeroFramedAry[i][j] < 10){
					System.out.print(zeroFramedAry[i][j] + "  ");
				}
				else{
					System.out.print(zeroFramedAry[i][j] + " ");
				}
			}
			System.out.println();
		}
		System.out.println();
	}
	
	public void printEQ(){
		System.out.print("EQ Array: ");
		for(int i = 0; i <= newLabel; i++){
			System.out.print(EQAry[i] + " ");
		}
		System.out.println();
		System.out.println();
	}
	
	public void printCCProperty(){
		System.out.println(numRows + " " + numCols + " " + newMin + " " + newMax);
		System.out.println(properties.length - 1);
		for(int i = 1; i < properties.length; i++){
			System.out.println("-----------------");
			System.out.println(i);
			System.out.println(properties[i].numpx);
			System.out.println((properties[i].minRow-1) + " " + (properties[i].minCol-1));
			System.out.println((properties[i].maxRow-1) + " " + (properties[i].maxCol-1));			
		}
	}
	
}
