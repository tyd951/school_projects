public class boundaryPt {
	int x;
	int y;
	int maxVotes;
	double maxDist;
	int corner;
	int localMax;
	
	public boundaryPt(int r, int c){
		x = r;
		y = c;
		maxVotes = 0;
		maxDist = 0.0;
		corner = 1;
		localMax = 0;
	}
	
	public void printPt(){
		System.out.println("x:"+x + " y:"+y);
	}
	
	public void printPtInOneLine(){
		System.out.print("x:"+x + " y:"+y + ", ");
	}
	
	public void printCorner(){
		System.out.println(x +" "+ y +" "+ corner);
	}
	
	public void printVotes(){
		System.out.println(x +" "+ y +" "+ maxVotes);
	}
}
